# Prisma — Evaluation Command Center (Design Prototype)

A static, offline, navigable **design prototype** for **Prisma**, a local-first
platform for production LLM engineering. This package demonstrates the approved
**Concept B — Evaluation Command Center** direction across nine fully navigable views.

> This is a **design prototype only**. It contains **no real application logic**,
> no backend, and no API. All data is **mock engineering data** used to communicate
> the intended product experience for portfolio and design-review purposes.

---

## Purpose

Communicate the engineering quality and interaction model of Prisma's evaluation
and observability surface: quality gates, golden cases, prompt regression, runtime
metrics, workflow traces, request inspection, retrieved context and citations.

## How to open

Just open the file — no build, no server, no install:

```text
index.html
```

Double-click `index.html`, or open it in any modern browser. Everything runs
locally from the filesystem.

## What's included

```text
index.html    — all nine views + layout
styles.css    — refined Concept B theme (dark, high-contrast, engineering-first)
app.js        — navigation, active-menu highlight, mock-data rendering, charts
README.md     — this file
```

## Navigable views

1. **Engineering Overview** — platform-wide status and subsystem health
2. **Evaluation Command Center** — quality gates, scorecards, golden cases, regression
3. **Golden Cases** — full behavioral-contract table with baseline deltas
4. **Prompt Regression** — prompt diffs scored against baseline
5. **Runtime Metrics** — latency, throughput and per-stage breakdown
6. **Workflow Timeline** — single-request deterministic stage waterfall
7. **Request Inspector** — request table with selectable detail panel
8. **Retrieved Context** — reranked chunks and context assembly
9. **Citation Inspector** — claim-to-source grounding map

Navigate from the left sidebar, from in-view links, or via the URL hash
(e.g. `index.html#runtime`). Selecting a request row updates its detail panel;
the runtime-artifact card expands and collapses.

## Constraints honored

- No build step · no npm · no bundler
- No frameworks (no React, no Vue, no Next.js)
- No CDN, external fonts, images, or assets
- No backend, no API, no network calls
- Runs fully offline from a local file

## Notes

- **Mock data only.** Metrics, cases, traces and citations are illustrative.
- **Design-only.** No business logic is implemented; interactions are limited to
  navigation, selection, expand/collapse, hover and transitions.
- Visual direction is the approved refined Concept B — dark technical console,
  strong hierarchy, professional density.
